package es.indra.models;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.condition.DisabledIfSystemProperty;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

public class ProductoTest {

	Producto producto;

	// Los metodos anotados como @BeforeAll y @AfterAll siempre han de ser estáticos
	// y ademas no pueden estar dentro de clases anidadas
	
	@BeforeAll
	static void inicioClasePrueba() {
		// Iniciar el log donde almacenamos el resultado de las pruebas
		System.out.println("Empezamos a probar la clase ProductoTest");
	}

	@AfterAll
	static void finClasePrueba() {
		System.out.println("Hemos terminado de probar la clase ProductoTest");
	}

	@BeforeEach
	void inicioPrueba() {
		producto = new Producto(1, "Impresora", 129.95);
		System.out.println("Producto creado para realizar la prueba");
	}

	@AfterEach
	void finPrueba() {
		System.out.println("Prueba terminada");
	}

	@Nested
	@DisplayName("Probando los test de la clase Producto")
	@Tag("producto")
	class ProductoPruebas {

		@Test
		@DisplayName("Probando la descripcion de producto")
		void testDescripcion() {
			// Patron AAA

			// Arrange -> Preparacion
			// Producto producto = new Producto(1, "Impresora", 129.95);

			// Act -> Ejecucion
			String descripcionEsperada = "Impresora";
			String descripcionReal = producto.getDescripcion();

			// Assert -> Comprobacion
			Assertions.assertEquals(descripcionEsperada, descripcionReal);
		}

		@Test
		@DisplayName("Probando el precio del producto")
		void testPrecio() {
			// Producto producto = new Producto(1, "Impresora", 129.95);
			// Assertions.assertTrue(producto.getPrecio() > 0);
			Assertions.assertFalse(producto.getPrecio() <= 0);
		}

		// Testear la igualdad de productos
		@Test
		@DisplayName("Probando la igualdad de productos")
		void testIgualdadProductos() {
			// Producto producto = new Producto(1, "Impresora", 129.95);
			Producto producto2 = new Producto(1, "Impresora", 129.95);
			Assertions.assertEquals(producto, producto2);
		}

		@Test
		@DisplayName("Probando la excepcion de precio negativo")
		void testPrecioNegativoException() {
			// Producto producto = new Producto(1, "Impresora", 129.95);
			Exception ex = Assertions.assertThrows(Exception.class, () -> {
				producto.setPrecio(-123);
			});

			String msgReal = ex.getMessage();
			String msgEsperado = "El precio no puede ser negativo";
			Assertions.assertEquals(msgEsperado, msgReal);

			String tipoReal = ex.getClass().getName();
			String tipoEsperado = "es.indra.utils.PrecioNegativoException";
			Assertions.assertEquals(tipoEsperado, tipoReal);
		}

	}
	
	@Nested
	@DisplayName("Probando los test de la clase Proveedor")
	class ProveedorPruebas{
		
		@Test
		@Tag("proveedor")
		void testRelacionProductoProveedor() {
			Proveedor proveedor = new Proveedor();
			proveedor.setNombre("HP");
			
			proveedor.addProducto(producto);
			
			Assertions.assertAll(
					// La lista de productos no es nula
					() -> Assertions.assertNotNull(proveedor.getProductos()),
					// Comprobar si hay un producto en la lista
					() -> Assertions.assertTrue(proveedor.getProductos().size() == 1),
					// Si el proveedor tiene un producto Impresora
					() -> Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
							.filter(prod -> "Impresora".equals(prod.getDescripcion()))
							.findFirst()
							.get()
							.getDescripcion())
			);					
		}
		
		@Test
		// Para probarlo run configurations: Include producto & proveedor para que se cumplan ambas
		@Tag("producto")
		@Tag("proveedor")
		void testProductoProveedor() {
			Proveedor proveedor = new Proveedor();
			proveedor.setNombre("HP");
			
			proveedor.addProducto(producto);
			
			Assertions.assertAll(
					() -> Assertions.assertNotNull(producto.getProveedor()),
					() -> Assertions.assertEquals("HP", producto.getProveedor().getNombre())
			);
		}
	}
	
	@Nested
	@DisplayName("Habilitar o deshabilitar pruebas segun SO o JRE")
	class SO_JRE{
		
		@Test
		@EnabledOnOs(OS.WINDOWS)
		void testSOWindows() {
			System.out.println("Tu SO es Windows");
		}
		
		@Test
		@EnabledOnOs({OS.MAC, OS.LINUX})
		void testSOMacLinux() {
			System.out.println("Tu SO es Windows");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_8)
		void testJava8() {
			System.out.println("Probando test en Java 8");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_26)
		void testJava26() {
			System.out.println("Probando test en Java 26");
		}
		
	}
	
	@Nested
	@DisplayName("Habilitar o deshabilitar pruebas segun propiedades del sistema")
	class SystemProperties{
		
		@Test
		void mostrarPropiedadesSistema() {
			System.getProperties().forEach( (k,v) -> System.out.println(k + ": " + v));
		}
		
		// java.version: 1.8.0_482
		@Test
		@EnabledIfSystemProperty(named = "java.version", matches = "1.8.0_482")
		void testJavaVersion() {
			System.out.println("Tu version de Java es 1.8.0_482");
		}
		
		// Tambien funciona con expresiones regulares
		@Test
		@EnabledIfSystemProperty(named = "java.version", matches = "1.8.*")
		void testJavaVersion2() {
			System.out.println("Tu version de Java es 1.8.*");
		}
		
		@Test
		@DisabledIfSystemProperty(named = "java.version", matches = "22.*")
		void testJavaVersion3() {
			System.out.println("Tu version de Java es 22.*");
		}
		
	}
	
	// Que es Assumptions?
	// Habilitar o deshabilitar un test o parte del test, en funcion
	// de una condicion de forma programativa
	@Test
	@DisplayName("Probando el precio del producto con assumptions")
	void testPrecioAssumptions() {
		
		boolean condicion = producto != null;
		//boolean condicion = producto == null;
		
		Assumptions.assumingThat(condicion, 
				() -> {
					Assertions.assertTrue(producto.getPrecio() > 0);
					System.out.println("Precio positivo");
					Assertions.assertEquals(129.95, producto.getPrecio());
					Assertions.assertEquals("Impresora", producto.getDescripcion());
				});		
	}
	
	@RepeatedTest(value = 4, name = "Repetición número {currentRepetition} de {totalRepetitions}")
	void testNumerosAleatorios(RepetitionInfo infoRep) {
		System.out.println("Estamos en la repeticion: " + infoRep.getCurrentRepetition() + 
				" de " + infoRep.getTotalRepetitions());
		double numero = Math.random();
		System.out.println(numero);
		Assertions.assertTrue(numero > 0);
	}
	
	@Nested
	class TestParametrizados{
		
		@ParameterizedTest(name = "parametro {index} con valor {0}")
		@ValueSource(doubles = {129.85, -30, 275, 0})
		void testPrecio(double precio) {
			producto.setPrecio(precio);
			Assertions.assertTrue(producto.getPrecio() > 0);
		}
		
		@ParameterizedTest(name = "parametro {index} con valor {1}")
		@CsvSource({"0,129.85", "1,-30", "2,275", "3,0"})
		void testPrecioCsvSource(String idx, String precio) {
			producto.setPrecio(Double.parseDouble(precio));
			Assertions.assertTrue(producto.getPrecio() > 0);
		}
		
		@ParameterizedTest(name = "parametro {index} con valor {0}")
		@CsvFileSource(resources = "/datos.csv")
		void testPrecioCsvFileSource(String precio) {
			producto.setPrecio(Double.parseDouble(precio));
			Assertions.assertTrue(producto.getPrecio() > 0);
		}
		
		@ParameterizedTest(name = "parametro {index} con valor {0}")
		@MethodSource("es.indra.models.ProductoTest#queryPrecios")
		void testPrecioMethodSource(Double precio) {
			producto.setPrecio(precio);
			Assertions.assertTrue(producto.getPrecio() > 0);
		}
				
	}
	
	// El metodo debe ser estatico y por eso no puede estar en clase anidada
	static List<Double> queryPrecios(){
		// Simulamos que lanzamos una query a la BBDD para traer la lista de precios
		return Arrays.asList(129.85, -30.0, 275.0, 0.0);
	}
	
	// Queremos que la prueba falle cuando supere x tiempo
	// Util para controlar procesos lentos
	@Test
	@Timeout(value = 1000, unit = TimeUnit.MILLISECONDS)
	void testTimeout() throws InterruptedException {
		// Forzamos al hilo para que espere 2 segundos
		Thread.sleep(500);
	}
	
	// Hay otra forma de hacer lo mismo
	@Test
	void testTimeout2() throws InterruptedException {
		// Forzamos al hilo para que espere 2 segundos
		Assertions.assertTimeout(Duration.ofSeconds(1), () -> {
			Thread.sleep(2000);
		});		
	}

}









