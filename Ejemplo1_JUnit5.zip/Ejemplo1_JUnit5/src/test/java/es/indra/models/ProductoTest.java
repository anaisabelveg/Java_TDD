package es.indra.models;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

public class ProductoTest {

	Producto producto;

	// Los metodos anotados como @BeforeAll y @AfterAll siempre han de ser estáticos
	@BeforeAll
	static void inicioClasePrueba() {
		// Iniciar el log donde almacenamos el resultado de las pruebas
		System.out.println("Empezamos a probar la clase ProductoTest");
	}

	@AfterAll
	static void finClasePrueba() {
		System.out.println("Hemos terminado de probar la clase ProductoTest");
	}

	@BeforeEach
	void inicioPrueba() {
		producto = new Producto(1, "Impresora", 129.95);
		System.out.println("Producto creado para realizar la prueba");
	}

	@AfterEach
	void finPrueba() {
		System.out.println("Prueba terminada");
	}

	@Nested
	@DisplayName("Probando los test de la clase Producto")
	class ProductoPruebas {

		@Test
		@DisplayName("Probando la descripcion de producto")
		void testDescripcion() {
			// Patron AAA

			// Arrange -> Preparacion
			// Producto producto = new Producto(1, "Impresora", 129.95);

			// Act -> Ejecucion
			String descripcionEsperada = "Impresora";
			String descripcionReal = producto.getDescripcion();

			// Assert -> Comprobacion
			Assertions.assertEquals(descripcionEsperada, descripcionReal);
		}

		@Test
		@DisplayName("Probando el precio del producto")
		void testPrecio() {
			// Producto producto = new Producto(1, "Impresora", 129.95);
			// Assertions.assertTrue(producto.getPrecio() > 0);
			Assertions.assertFalse(producto.getPrecio() <= 0);
		}

		// Testear la igualdad de productos
		@Test
		@DisplayName("Probando la igualdad de productos")
		void testIgualdadProductos() {
			// Producto producto = new Producto(1, "Impresora", 129.95);
			Producto producto2 = new Producto(1, "Impresora", 129.95);
			Assertions.assertEquals(producto, producto2);
		}

		@Test
		@DisplayName("Probando la excepcion de precio negativo")
		void testPrecioNegativoException() {
			// Producto producto = new Producto(1, "Impresora", 129.95);
			Exception ex = Assertions.assertThrows(Exception.class, () -> {
				producto.setPrecio(-123);
			});

			String msgReal = ex.getMessage();
			String msgEsperado = "El precio no puede ser negativo";
			Assertions.assertEquals(msgEsperado, msgReal);

			String tipoReal = ex.getClass().getName();
			String tipoEsperado = "es.indra.utils.PrecioNegativoException";
			Assertions.assertEquals(tipoEsperado, tipoReal);
		}

	}

}
