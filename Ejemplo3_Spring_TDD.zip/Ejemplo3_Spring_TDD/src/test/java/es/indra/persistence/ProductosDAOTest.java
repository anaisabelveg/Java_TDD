package es.indra.persistence;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import es.indra.entities.Producto;

@DataJpaTest
@Transactional
public class ProductosDAOTest {

	@Autowired
	private ProductosDAO dao;

	@Test
	void testCrearProducto() {
		Producto nuevo = new Producto("Prueba", 123.45);

		Producto creado = dao.save(nuevo);

		Assertions.assertNotNull(creado);
		Assertions.assertEquals(7L, creado.getID());
	}

	@Test
	void testBuscarProducto() {
		Optional<Producto> opProducto = dao.findById(3L);

		Assertions.assertTrue(opProducto.isPresent());
		Assertions.assertEquals("Raton", opProducto.get().getDescripcion());
	}

	@Test
	void testBuscarProductoNoExiste() {
		Optional<Producto> opProducto = dao.findById(3654466L);

		Assertions.assertFalse(opProducto.isPresent());
	}

	@Test
	void testConsultarTodos() {
		List<Producto> lista = dao.findAll();
		
		Assertions.assertEquals(6, lista.size());
	}

	@Test
	void testModificarPrecio() {
		Producto producto = new Producto(5L, "Pizarra digital", 450.95);
		
		Producto modificado = dao.save(producto);
		
		Assertions.assertEquals(450.95, modificado.getPrecio());
		Assertions.assertEquals(5L, modificado.getID());
		Assertions.assertEquals("Pizarra digital", modificado.getDescripcion());
	}

	@Test
	void testEliminarProducto() {
		dao.deleteById(6L);
		List<Producto> lista = dao.findAll();
		
		Assertions.assertEquals(5, lista.size());	
	}

}
