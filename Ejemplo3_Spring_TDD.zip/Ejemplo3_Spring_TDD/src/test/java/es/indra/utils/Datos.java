package es.indra.utils;

import java.util.Arrays;
import java.util.List;

import es.indra.entities.Producto;

public class Datos {
	
	public static List<Producto> lista = Arrays.asList(
			new Producto(1L, "Monitor", 129.50),
			new Producto(2L, "Teclado", 50.89),
			new Producto(3L, "Raton", 25.95),
			new Producto(4L, "Scanner", 230),
			new Producto(5L, "Pizarra digital", 500),
			new Producto(6L, "Disco Duro", 89.75));
	
	public static Producto PRODUCTO = new Producto(2L, "Teclado", 50.89);
	
	public static Producto PRODUCTO_NUEVO = new Producto(7L, "Prueba", 123.45);

}
