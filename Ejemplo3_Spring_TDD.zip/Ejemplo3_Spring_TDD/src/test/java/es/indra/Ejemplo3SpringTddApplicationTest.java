package es.indra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Ejemplo3SpringTddApplicationTest {
	
	@Test
	void contextLoads() {
		
	}

}
