package es.indra.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.entities.Producto;

@RestController
@RequestMapping("/api/productos")
public class ProductosREST {
	
	@Autowired
	private IProductosBS bs;
	
	// http://localhost:8090/api/productos/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos();
	}
	
	// http://localhost:8090/api/productos/buscar/3
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id) {
		return bs.buscarProducto(id);
	}
	
	// http://localhost:8090/api/productos/crear/descripcion/Prueba/precio/123.45
	@PostMapping("/crear/descripcion/{descripcion}/precio/{precio}")
	public Producto crear(@PathVariable String descripcion, @PathVariable double precio) {
		return bs.crearNuevo(descripcion, precio);
	}
	
	// http://localhost:8090/api/productos/modificar/2/precio/99.99
	@PutMapping("/modificar/{id}/precio/{nuevoPrecio}")
	public Producto modificar(@PathVariable Long id, @PathVariable double nuevoPrecio) {
		return bs.modificarPrecio(id, nuevoPrecio);
	}
	
	// http://localhost:8090/api/productos/eliminar/6
	@DeleteMapping("/eliminar/{id}")
	public boolean eliminar(@PathVariable Long id) {
		return bs.eliminarProducto(id);
	}

}
