package es.indra.persistence;

import java.util.Arrays;
import java.util.List;

public class ActoresDAOImpl implements IActoresDAO{

	@Override
	public List<String> findActoresByPeliculaId(Long id) {
		System.out.println("Metodo findActoresByPeliculaId de ActoresDAOImpl");
		return Arrays.asList("Actor 1", "Actor 2", "Actor 3");
	}

	@Override
	public void crearListaActores(List<String> actores) {
		System.out.println("Metodo crearListaActores de ActoresDAOImpl");		
	}

}
