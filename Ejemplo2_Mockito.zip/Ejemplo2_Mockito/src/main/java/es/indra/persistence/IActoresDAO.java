package es.indra.persistence;

import java.util.List;

public interface IActoresDAO {

	List<String> findActoresByPeliculaId(Long id);
	
	void crearListaActores(List<String> actores);
}
