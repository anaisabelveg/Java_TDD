package es.indra.business;

import es.indra.models.Pelicula;

public interface IPeliculasBS {
	
	Pelicula findPeliculaByNombre(String nombre);
	
	Pelicula crear(Pelicula pelicula);

}
