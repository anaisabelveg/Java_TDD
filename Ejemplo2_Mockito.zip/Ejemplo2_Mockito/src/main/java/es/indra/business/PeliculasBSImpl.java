package es.indra.business;

import java.util.Optional;

import es.indra.models.Pelicula;
import es.indra.persistence.IPeliculasDAO;

public class PeliculasBSImpl implements IPeliculasBS {

	private IPeliculasDAO peliculasDAO;

	public PeliculasBSImpl(IPeliculasDAO peliculasDAO) {
		super();
		this.peliculasDAO = peliculasDAO;
	}

	@Override
	public Pelicula findPeliculaByNombre(String nombre) {
		Optional<Pelicula> opPelicula = peliculasDAO.findAll()
			.stream()
			.filter(peli -> peli.getNombre().contains(nombre))
			.findFirst();
		
		Pelicula pelicula = null;
		if (opPelicula.isPresent())
			pelicula = opPelicula.get();
		
		return pelicula;
	}

	@Override
	public Pelicula crear(Pelicula pelicula) {
		return peliculasDAO.crear(pelicula);
	}

}
