package es.indra.utils;

import java.util.Arrays;
import java.util.List;

import es.indra.models.Pelicula;

public class Datos {
	
	public static List<Pelicula> PELICULAS = Arrays.asList(
			new Pelicula(1L, "El 47"),
			new Pelicula(2L, "La Infiltrada"),
			new Pelicula(3L, "La habitacion de al lado"));
	
	public static Pelicula PELICULA = new Pelicula(4L, "Harry Potter");
	
	public static Pelicula PELICULA_NULL = new Pelicula(null, "La bola negra");
	
	public static List<String> ACTORES = Arrays.asList("Actor 1", "Actor 2", "Actor 3");

}
