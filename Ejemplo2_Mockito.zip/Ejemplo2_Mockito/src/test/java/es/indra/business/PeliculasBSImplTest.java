package es.indra.business;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatcher;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;

import es.indra.models.Pelicula;
import es.indra.persistence.ActoresDAOImpl;
import es.indra.persistence.IActoresDAO;
import es.indra.persistence.IPeliculasDAO;
import es.indra.persistence.PeliculasDAOImpl;
import es.indra.utils.Datos;

@ExtendWith(MockitoExtension.class)
public class PeliculasBSImplTest {
	
	@Mock
	IPeliculasDAO dao;
	
	@Mock
	// Mockito.doCallRealMethod() necesito el mock de la clase y no de la interface
	//IActoresDAO actoresDAO;
	ActoresDAOImpl actoresDAO;
	
	@InjectMocks
	// No puedo inyectar mocks en una interface, es necesario utilizar la clase
	PeliculasBSImpl bs;
	
	@Captor
	ArgumentCaptor<Long> captor;
	
	@BeforeEach
	void inicioPrueba() {
		// Crear el mock (objeto ficticio del dao)
		//dao = Mockito.mock(IPeliculasDAO.class);
		//actoresDAO = Mockito.mock(IActoresDAO.class);
		//bs = new PeliculasBSImpl(dao, actoresDAO);
		
		// Al usar anotaciones necesitamos activarlas:
		// tenemos 2 formas de hacerlo: programatica o con la anotacion @ExtendWith
		// MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void testFindPeliculaByNombre() {
		// Cargar los datos al llamar al findAll() del dao
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		
		Pelicula pelicula = bs.findPeliculaByNombre("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
		
	}
	
	@Test
	void testCrearPelicula() {
		// Patron AAA  -> JUnit (TDD)
		// Patron Given, When, Then -> Mockito (BDD)
		
		// 1.- Given
		Pelicula peliculaNueva = Datos.PELICULA;
		//Mockito.when(dao.crear(peliculaNueva)).thenReturn(Datos.PELICULA);
		
		// Ahora mockeamos la pelicula da igual que objeto pasamos porque siempre retorna Datos.PELICULA
		Mockito.when(dao.crear(Mockito.any(Pelicula.class))).thenReturn(Datos.PELICULA);
		
		// 2.- When
		Pelicula pelicula = bs.crear(peliculaNueva);
		
		// 3.- Then
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals("Harry Potter", pelicula.getNombre());
		
		// Con verify comprobamos que se invoco al metodo crear() del mock dao
		Mockito.verify(dao).crear(Mockito.any(Pelicula.class)); // ok por dao es un mock
		//Mockito.verify(bs).crear(Mockito.any(Pelicula.class));   // error por bs es un objeto real
	}
	
	@Test
	void testCrearPeliculaConActores() {
		
		// 1.- Given
		Pelicula peliculaNueva = Datos.PELICULA;
		peliculaNueva.setActores(Datos.ACTORES);
		
		// Ahora mockeamos la pelicula da igual que objeto pasamos porque siempre retorna Datos.PELICULA
		Mockito.when(dao.crear(Mockito.any(Pelicula.class))).thenReturn(Datos.PELICULA);
		
		// 2.- When
		Pelicula pelicula = bs.crear(peliculaNueva);
		
		// 3.- Then
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals("Harry Potter", pelicula.getNombre());
		Assertions.assertEquals(3, pelicula.getActores().size());
		
		// Con verify comprobamos que se invoco al metodo crear() del mock dao
		Mockito.verify(dao).crear(Mockito.any(Pelicula.class)); // ok por dao es un mock
		Mockito.verify(actoresDAO).crearListaActores(Mockito.anyList());   // mockear una lista
	}
	
	@Test
	void testFindPeliculaByNombreConActores() {
	
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actoresDAO.findActoresByPeliculaId(2L)).thenReturn(Datos.ACTORES);
		
		Pelicula pelicula = bs.findPeliculaByNombreConActores("Infiltrada");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(2L, pelicula.getId());
		Assertions.assertEquals("La Infiltrada", pelicula.getNombre());
		Assertions.assertEquals(3, pelicula.getActores().size());	
		
		// Con verify estos son los metodos del mock que hemos invocado
		Mockito.verify(dao).findAll();
		Mockito.verify(actoresDAO).findActoresByPeliculaId(2L);
		
		// Pero este metodo no es invocado
		// Mockito.verify(actoresDAO).crearListaActores(Datos.ACTORES);   ERROR
		Mockito.verify(actoresDAO, Mockito.never()).crearListaActores(Mockito.anyList());
	}
	
	@Test
	void testExcepciones() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actoresDAO.findActoresByPeliculaId(Mockito.anyLong()))
				.thenThrow(RuntimeException.class);
		
		Exception ex = Assertions.assertThrows(RuntimeException.class, () -> {
			bs.findPeliculaByNombreConActores("habitacion");
		});
		
		Assertions.assertEquals(RuntimeException.class, ex.getClass());		
	}
	
	// Con ArgumentMatchers validar que argumentos estamos pasando en las llamadas del mock
	@Test
	void testArgumentMatchers() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actoresDAO.findActoresByPeliculaId(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		bs.findPeliculaByNombreConActores("habitacion");
		
		Mockito.verify(actoresDAO).findActoresByPeliculaId(ArgumentMatchers.argThat(arg -> arg != null && arg.equals(3L)));
		Mockito.verify(actoresDAO).findActoresByPeliculaId(ArgumentMatchers.eq(3L));
	}
	
	// Crear un ArgumentMatcher personalizado
	public static class MiArgumentMatcher implements ArgumentMatcher<Long>{
		
		private Long argument;

		@Override
		public boolean matches(Long argument) {
			this.argument = argument;
			return argument != null && argument > 0;
		}
		
		@Override
		public String toString() {
			return "ERROR: " + argument + " debe ser un numero positivo";
		}	
	}
	
	@Test
	void testMiArgumentMatchers() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actoresDAO.findActoresByPeliculaId(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		bs.findPeliculaByNombreConActores("habitacion");
		
		Mockito.verify(actoresDAO).findActoresByPeliculaId(ArgumentMatchers.argThat(new MiArgumentMatcher()));
	}
	
	@Test
	void testCapturarArgumentos() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		bs.findPeliculaByNombreConActores("habitacion");
		
		// Crear una instancia de ArgumentCaptor para capturar los argumentos
		// Esto se puede hacer de 2 formas: programatica o @Captor 
		// ArgumentCaptor<Long> captor = ArgumentCaptor.forClass(Long.class);
		
		// Capturar los argumentos
		Mockito.verify(actoresDAO).findActoresByPeliculaId(captor.capture());
		Assertions.assertEquals(3L, captor.getValue());
	}
	
	@Test
	void testDoThrowVoid() {
		Pelicula peliculaNueva = Datos.PELICULA;
		peliculaNueva.setActores(Datos.ACTORES);
		
		// No puedo utilizar when cuando el metodo es de tipo void
		//Mockito.when(actoresDAO.crearListaActores(null)).thenThrow(RuntimeException.class);
		
		// La alternativa es utilizar doThrow
		Mockito.doThrow(RuntimeException.class).when(actoresDAO).crearListaActores(Mockito.anyList());
		
		Assertions.assertThrows(RuntimeException.class, () -> {
			bs.crear(peliculaNueva);
		});
	}
	
	@Test
	void testCallRealMethods() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		
		// Vamos a forzar para que el mock llame al metodo real
		Mockito.doCallRealMethod().when(actoresDAO).findActoresByPeliculaId(Mockito.anyLong());
		
		Pelicula pelicula = bs.findPeliculaByNombreConActores("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
		Assertions.assertEquals(3, pelicula.getActores().size());
	}
	
	// Spy es un hibrido entre los mock y los objetos reales
	// Spy al igual que Mockito.doCallRealMethod() no funciona con interfaces o clases abstractas
	// Funciona de forma programatica o con anotaciones
	@Test
	void testSpyProgramatica() {
		PeliculasDAOImpl peliculasSpy = Mockito.spy(PeliculasDAOImpl.class);
		ActoresDAOImpl actoresSpy = Mockito.spy(ActoresDAOImpl.class);
		IPeliculasBS peliculasBS = new PeliculasBSImpl(peliculasSpy, actoresSpy);
		
		// Con spy puedo llamar al metodo real
		//Mockito.when(actoresSpy.findActoresByPeliculaId(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		// Con spy puedo llamar a los metodos ficticios
		Mockito.doReturn(Datos.PELICULAS).when(peliculasSpy).findAll();
		Mockito.doReturn(Datos.ACTORES).when(actoresSpy).findActoresByPeliculaId(Mockito.anyLong());
		
		
		Pelicula pelicula = peliculasBS.findPeliculaByNombreConActores("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
		Assertions.assertEquals(3, pelicula.getActores().size());		
	}
	
	@Test
	void testOrdenEnMocks() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		
		bs.findPeliculaByNombreConActores("47");
		bs.findPeliculaByNombreConActores("Infiltrada");
		
		InOrder order = Mockito.inOrder(actoresDAO, dao); // Aqui el orden de los mock da igual
		order.verify(dao).findAll();
		order.verify(actoresDAO).findActoresByPeliculaId(1L);
		
		order.verify(dao).findAll();
		order.verify(actoresDAO).findActoresByPeliculaId(2L);
	}
	
	@Test
	void testNumeroInvocaciones() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		bs.findPeliculaByNombreConActores("Infiltrada");
		
		Mockito.verify(actoresDAO).findActoresByPeliculaId(2L);
		//Mockito.verify(actoresDAO, Mockito.never()).findActoresByPeliculaId(2L); ERROR
		Mockito.verify(actoresDAO, Mockito.times(1)).findActoresByPeliculaId(2L);
		Mockito.verify(actoresDAO, Mockito.atLeast(1)).findActoresByPeliculaId(2L);
		Mockito.verify(actoresDAO, Mockito.atLeastOnce()).findActoresByPeliculaId(2L);
		Mockito.verify(actoresDAO, Mockito.atMost(1)).findActoresByPeliculaId(2L);
		Mockito.verify(actoresDAO, Mockito.atMostOnce()).findActoresByPeliculaId(2L);
	}
	
	@Test
	void testCrearPeliculaIdIncremental() {
		Pelicula pelicula = Datos.PELICULA_NULL;
		pelicula.setActores(Datos.ACTORES);
		
		Mockito.when(dao.crear(Mockito.any(Pelicula.class))).then(new Answer<Pelicula>() {
			
			Long secuencia = 3L;

			@Override
			public Pelicula answer(InvocationOnMock invocation) throws Throwable {
				// Capturar la pelicula que vamos a crear
				Pelicula pelicula = invocation.getArgument(0);
				// En un entorno real lanzariamos findAll() para saber el ultimo id
				// Incrementar la secuencia y asignar el id a la pelicula
				pelicula.setId(++secuencia);
				return pelicula;
			}		
		});
		
		Pelicula peliculaNueva = bs.crear(Datos.PELICULA_NULL);
		
		Assertions.assertEquals(4L, peliculaNueva.getId());
		Assertions.assertEquals("La bola negra", peliculaNueva.getNombre());
	}
	
	// Otra forma de hacerlo con doAnswer
	@Test
	void testCrearPeliculaIdIncrementalDoAnswer() {
		Pelicula pelicula = Datos.PELICULA_NULL;
		pelicula.setActores(Datos.ACTORES);
		
		Mockito.doAnswer(new Answer<Pelicula>() {
			
			Long secuencia = 3L;

			@Override
			public Pelicula answer(InvocationOnMock invocation) throws Throwable {
				// Capturar la pelicula que vamos a crear
				Pelicula pelicula = invocation.getArgument(0);
				// En un entorno real lanzariamos findAll() para saber el ultimo id
				// Incrementar la secuencia y asignar el id a la pelicula
				pelicula.setId(++secuencia);
				return pelicula;
			}
		}).when(dao).crear(Mockito.any(Pelicula.class));
		
		Pelicula peliculaNueva = bs.crear(Datos.PELICULA_NULL);
		
		Assertions.assertEquals(null, peliculaNueva.getId());
		Assertions.assertEquals("La bola negra", peliculaNueva.getNombre());
	}
	

}

























