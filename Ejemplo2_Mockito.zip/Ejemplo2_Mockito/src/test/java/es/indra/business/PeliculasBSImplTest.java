package es.indra.business;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatcher;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import es.indra.models.Pelicula;
import es.indra.persistence.IActoresDAO;
import es.indra.persistence.IPeliculasDAO;
import es.indra.utils.Datos;

@ExtendWith(MockitoExtension.class)
public class PeliculasBSImplTest {
	
	@Mock
	IPeliculasDAO dao;
	
	@Mock
	IActoresDAO actoresDAO;
	
	@InjectMocks
	// No puedo inyectar mocks en una interface, es necesario utilizar la clase
	PeliculasBSImpl bs;
	
	@Captor
	ArgumentCaptor<Long> captor;
	
	@BeforeEach
	void inicioPrueba() {
		// Crear el mock (objeto ficticio del dao)
		//dao = Mockito.mock(IPeliculasDAO.class);
		//actoresDAO = Mockito.mock(IActoresDAO.class);
		//bs = new PeliculasBSImpl(dao, actoresDAO);
		
		// Al usar anotaciones necesitamos activarlas:
		// tenemos 2 formas de hacerlo: programatica o con la anotacion @ExtendWith
		// MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void testFindPeliculaByNombre() {
		// Cargar los datos al llamar al findAll() del dao
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		
		Pelicula pelicula = bs.findPeliculaByNombre("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
		
	}
	
	@Test
	void testCrearPelicula() {
		// Patron AAA  -> JUnit (TDD)
		// Patron Given, When, Then -> Mockito (BDD)
		
		// 1.- Given
		Pelicula peliculaNueva = Datos.PELICULA;
		//Mockito.when(dao.crear(peliculaNueva)).thenReturn(Datos.PELICULA);
		
		// Ahora mockeamos la pelicula da igual que objeto pasamos porque siempre retorna Datos.PELICULA
		Mockito.when(dao.crear(Mockito.any(Pelicula.class))).thenReturn(Datos.PELICULA);
		
		// 2.- When
		Pelicula pelicula = bs.crear(peliculaNueva);
		
		// 3.- Then
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals("Harry Potter", pelicula.getNombre());
		
		// Con verify comprobamos que se invoco al metodo crear() del mock dao
		Mockito.verify(dao).crear(Mockito.any(Pelicula.class)); // ok por dao es un mock
		//Mockito.verify(bs).crear(Mockito.any(Pelicula.class));   // error por bs es un objeto real
	}
	
	@Test
	void testCrearPeliculaConActores() {
		
		// 1.- Given
		Pelicula peliculaNueva = Datos.PELICULA;
		peliculaNueva.setActores(Datos.ACTORES);
		
		// Ahora mockeamos la pelicula da igual que objeto pasamos porque siempre retorna Datos.PELICULA
		Mockito.when(dao.crear(Mockito.any(Pelicula.class))).thenReturn(Datos.PELICULA);
		
		// 2.- When
		Pelicula pelicula = bs.crear(peliculaNueva);
		
		// 3.- Then
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals("Harry Potter", pelicula.getNombre());
		Assertions.assertEquals(3, pelicula.getActores().size());
		
		// Con verify comprobamos que se invoco al metodo crear() del mock dao
		Mockito.verify(dao).crear(Mockito.any(Pelicula.class)); // ok por dao es un mock
		Mockito.verify(actoresDAO).crearListaActores(Mockito.anyList());   // mockear una lista
	}
	
	@Test
	void testFindPeliculaByNombreConActores() {
	
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actoresDAO.findActoresByPeliculaId(2L)).thenReturn(Datos.ACTORES);
		
		Pelicula pelicula = bs.findPeliculaByNombreConActores("Infiltrada");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(2L, pelicula.getId());
		Assertions.assertEquals("La Infiltrada", pelicula.getNombre());
		Assertions.assertEquals(3, pelicula.getActores().size());	
		
		// Con verify estos son los metodos del mock que hemos invocado
		Mockito.verify(dao).findAll();
		Mockito.verify(actoresDAO).findActoresByPeliculaId(2L);
		
		// Pero este metodo no es invocado
		// Mockito.verify(actoresDAO).crearListaActores(Datos.ACTORES);   ERROR
		Mockito.verify(actoresDAO, Mockito.never()).crearListaActores(Mockito.anyList());
	}
	
	@Test
	void testExcepciones() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actoresDAO.findActoresByPeliculaId(Mockito.anyLong()))
				.thenThrow(RuntimeException.class);
		
		Exception ex = Assertions.assertThrows(RuntimeException.class, () -> {
			bs.findPeliculaByNombreConActores("habitacion");
		});
		
		Assertions.assertEquals(RuntimeException.class, ex.getClass());		
	}
	
	// Con ArgumentMatchers validar que argumentos estamos pasando en las llamadas del mock
	@Test
	void testArgumentMatchers() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actoresDAO.findActoresByPeliculaId(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		bs.findPeliculaByNombreConActores("habitacion");
		
		Mockito.verify(actoresDAO).findActoresByPeliculaId(ArgumentMatchers.argThat(arg -> arg != null && arg.equals(3L)));
		Mockito.verify(actoresDAO).findActoresByPeliculaId(ArgumentMatchers.eq(3L));
	}
	
	// Crear un ArgumentMatcher personalizado
	public static class MiArgumentMatcher implements ArgumentMatcher<Long>{
		
		private Long argument;

		@Override
		public boolean matches(Long argument) {
			this.argument = argument;
			return argument != null && argument > 0;
		}
		
		@Override
		public String toString() {
			return "ERROR: " + argument + " debe ser un numero positivo";
		}	
	}
	
	@Test
	void testMiArgumentMatchers() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actoresDAO.findActoresByPeliculaId(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		bs.findPeliculaByNombreConActores("habitacion");
		
		Mockito.verify(actoresDAO).findActoresByPeliculaId(ArgumentMatchers.argThat(new MiArgumentMatcher()));
	}
	
	@Test
	void testCapturarArgumentos() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		bs.findPeliculaByNombreConActores("habitacion");
		
		// Crear una instancia de ArgumentCaptor para capturar los argumentos
		// Esto se puede hacer de 2 formas: programatica o @Captor 
		// ArgumentCaptor<Long> captor = ArgumentCaptor.forClass(Long.class);
		
		// Capturar los argumentos
		Mockito.verify(actoresDAO).findActoresByPeliculaId(captor.capture());
		Assertions.assertEquals(3L, captor.getValue());
	}

}






