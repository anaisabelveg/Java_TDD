package es.indra.business;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import es.indra.models.Pelicula;
import es.indra.persistence.IPeliculasDAO;
import es.indra.utils.Datos;

public class PeliculasBSImplTest {
	
	IPeliculasDAO dao;
	IPeliculasBS bs;
	
	@BeforeEach
	void inicioPrueba() {
		// Crear el mock (objeto ficticio del dao)
		dao = Mockito.mock(IPeliculasDAO.class);
		bs = new PeliculasBSImpl(dao);
	}
	
	@Test
	void testFindPeliculaByNombre() {
		// Cargar los datos al llamar al findAll() del dao
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		
		Pelicula pelicula = bs.findPeliculaByNombre("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
		
	}
	
	@Test
	void testCrearPelicula() {
		// Patron AAA  -> JUnit (TDD)
		// Patron Given, When, Then -> Mockito (BDD)
		
		// 1.- Given
		Pelicula peliculaNueva = Datos.PELICULA;
		Mockito.when(dao.crear(peliculaNueva)).thenReturn(Datos.PELICULA);
		
		// 2.- When
		Pelicula pelicula = bs.crear(peliculaNueva);
		
		// 3.- Then
		Assertions.assertNotNull(pelicula);
	}

}






